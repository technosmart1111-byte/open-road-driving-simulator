import * as THREE from 'https://cdn.jsdelivr.net/npm/three@0.164.1/build/three.module.js';

const $ = (id)=>document.getElementById(id);
const translations = {
  en:{menu:"Menu",pause:"Pause",gear:"GEAR",fuel:"Fuel",condition:"Condition",network:"Network",play:"Play",garage:"Garage",settings:"Settings",multiplayer:"Multiplayer",missions:"Missions",help:"Help",resume:"Resume",language:"Language",graphics:"Graphics",audio:"Audio",controls:"Controls",gameplay:"Gameplay",quality:"Graphics preset",volume:"Master volume",engine:"Engine volume",music:"Music volume",sensitivity:"Steering sensitivity",units:"Speed unit",apply:"Apply",cancel:"Cancel",reset:"Reset defaults",close:"Close",save:"Save",create:"Create room",join:"Join room",roomCode:"Room code",playerName:"Player name",connect:"Connect",disconnect:"Disconnect",offline:"Offline",online:"Online",freeDrive:"Free Drive",garageTitle:"Garage & Vehicle",redCar:"Starter red car",paint:"Paint color",missionsTitle:"Missions",missionText:"Drive 1 km to complete your first distance challenge.",helpText:"Hold ▲ to accelerate, BRAKE to slow down, and ◀ / ▶ to steer. Use 📷 to change camera. Settings and your paint choice save locally.",coming:"This feature needs additional game content or a configured service.",settingsSaved:"Settings saved.",roomNeed:"Enter a room code and player name.",serverDown:"Multiplayer server is not reachable. Start the included server first.",joined:"Connected to multiplayer room.",left:"Disconnected from room.",paused:"Paused",driving:"Drive your world.",subtitle:"A 3D driving simulator prototype. Choose a mode and hit the road."},
  hi:{menu:"मेन्यू",pause:"रोकें",gear:"गियर",fuel:"ईंधन",condition:"गाड़ी की हालत",network:"नेटवर्क",play:"खेलें",garage:"गैरेज",settings:"सेटिंग्स",multiplayer:"मल्टीप्लेयर",missions:"मिशन",help:"मदद",resume:"फिर शुरू करें",language:"भाषा",graphics:"ग्राफिक्स",audio:"ऑडियो",controls:"कंट्रोल",gameplay:"गेमप्ले",quality:"ग्राफिक्स प्रीसेट",volume:"मुख्य आवाज़",engine:"इंजन आवाज़",music:"म्यूज़िक आवाज़",sensitivity:"स्टीयरिंग संवेदनशीलता",units:"स्पीड यूनिट",apply:"लागू करें",cancel:"रद्द करें",reset:"डिफ़ॉल्ट रीसेट",close:"बंद करें",save:"सेव करें",create:"रूम बनाएँ",join:"रूम जॉइन करें",roomCode:"रूम कोड",playerName:"खिलाड़ी का नाम",connect:"कनेक्ट",disconnect:"डिस्कनेक्ट",offline:"ऑफ़लाइन",online:"ऑनलाइन",freeDrive:"फ्री ड्राइव",garageTitle:"गैरेज और गाड़ी",redCar:"शुरुआती लाल कार",paint:"रंग चुनें",missionsTitle:"मिशन",missionText:"पहला दूरी चैलेंज पूरा करने के लिए 1 किमी चलाएँ।",helpText:"तेज़ चलाने के लिए ▲ दबाकर रखें, धीमा करने के लिए BRAKE और मोड़ने के लिए ◀ / ▶ दबाएँ। 📷 से कैमरा बदलें। सेटिंग्स और रंग इसी डिवाइस पर सेव होते हैं।",coming:"इस सुविधा के लिए अतिरिक्त गेम सामग्री या सर्वर सेटअप चाहिए।",settingsSaved:"सेटिंग्स सेव हो गईं।",roomNeed:"रूम कोड और खिलाड़ी का नाम भरें।",serverDown:"मल्टीप्लेयर सर्वर नहीं मिल रहा। पहले साथ दिया गया सर्वर शुरू करें।",joined:"मल्टीप्लेयर रूम से कनेक्ट हो गए।",left:"रूम से डिस्कनेक्ट हो गए।",paused:"गेम रुका हुआ है",driving:"अपनी दुनिया में ड्राइव करें।",subtitle:"3D ड्राइविंग सिम्युलेटर प्रोटोटाइप। मोड चुनें और सड़क पर निकलें।"},
  ru:{menu:"Меню",pause:"Пауза",gear:"ПЕРЕДАЧА",fuel:"Топливо",condition:"Состояние",network:"Сеть",play:"Играть",garage:"Гараж",settings:"Настройки",multiplayer:"Мультиплеер",missions:"Миссии",help:"Помощь",resume:"Продолжить",language:"Язык",graphics:"Графика",audio:"Звук",controls:"Управление",gameplay:"Игровой процесс",quality:"Пресет графики",volume:"Общая громкость",engine:"Громкость двигателя",music:"Громкость музыки",sensitivity:"Чувствительность руля",units:"Единицы скорости",apply:"Применить",cancel:"Отмена",reset:"Сбросить",close:"Закрыть",save:"Сохранить",create:"Создать комнату",join:"Войти в комнату",roomCode:"Код комнаты",playerName:"Имя игрока",connect:"Подключиться",disconnect:"Отключиться",offline:"Не в сети",online:"В сети",freeDrive:"Свободная езда",garageTitle:"Гараж и автомобиль",redCar:"Стартовый красный автомобиль",paint:"Цвет кузова",missionsTitle:"Миссии",missionText:"Проедьте 1 км, чтобы выполнить первое испытание.",helpText:"Удерживайте ▲ для ускорения, BRAKE для торможения, ◀ / ▶ для поворота. Нажмите 📷 для смены камеры. Настройки и цвет сохраняются на устройстве.",coming:"Для этой функции нужны дополнительные игровые ресурсы или настроенный сервис.",settingsSaved:"Настройки сохранены.",roomNeed:"Введите код комнаты и имя игрока.",serverDown:"Сервер мультиплеера недоступен. Сначала запустите сервер из комплекта.",joined:"Подключено к комнате.",left:"Отключено от комнаты.",paused:"Пауза",driving:"Исследуйте свой мир.",subtitle:"Прототип 3D-симулятора вождения. Выберите режим и отправляйтесь в путь."}
};
const defaults={lang:"en",quality:"Medium",master:0.75,engine:0.75,music:0.35,sensitivity:1,unit:"kmh",paint:"#e53935",steerAssist:true};
let settings={...defaults,...JSON.parse(localStorage.getItem("openroad-settings")||"{}")};
let running=false, paused=true, steering=0, throttle=0, braking=0, cameraMode=0, totalDistance=0, fuel=100, condition=100;
let ws=null, myId=null, remotePlayers=new Map(), lastNet=0, roomCode="";
let audioCtx=null, engineOsc=null, engineGain=null;
const scene=new THREE.Scene(); scene.background=new THREE.Color(0x91b9d4); scene.fog=new THREE.Fog(0x91b9d4,80,330);
const camera=new THREE.PerspectiveCamera(65,innerWidth/innerHeight,0.1,800);
const renderer=new THREE.WebGLRenderer({antialias:true,powerPreference:"high-performance"});
renderer.setPixelRatio(Math.min(devicePixelRatio,1.75)); renderer.setSize(innerWidth,innerHeight); renderer.shadowMap.enabled=true; renderer.shadowMap.type=THREE.PCFSoftShadowMap; renderer.outputColorSpace=THREE.SRGBColorSpace;
$("game").appendChild(renderer.domElement);
scene.add(new THREE.HemisphereLight(0xe4f4ff,0x53613e,2.0));
const sun=new THREE.DirectionalLight(0xfff0d6,2.4); sun.position.set(-35,60,30); sun.castShadow=true; sun.shadow.mapSize.set(1024,1024); scene.add(sun);
const mats={road:new THREE.MeshStandardMaterial({color:0x343a43,roughness:.94}),line:new THREE.MeshStandardMaterial({color:0xf2f1df}),grass:new THREE.MeshStandardMaterial({color:0x5e8b55}),side:new THREE.MeshStandardMaterial({color:0xb0b4b4}),trunk:new THREE.MeshStandardMaterial({color:0x63452f}),leaf:new THREE.MeshStandardMaterial({color:0x2f6d42}),glass:new THREE.MeshStandardMaterial({color:0x8bb6ca,metalness:.25,roughness:.2}),black:new THREE.MeshStandardMaterial({color:0x15191e,roughness:.7}),white:new THREE.MeshStandardMaterial({color:0xf0f2f5}),yellow:new THREE.MeshStandardMaterial({color:0xf4c94b,emissive:0x443000})};
function box(w,h,d,mat,x,y,z,parent=scene){const m=new THREE.Mesh(new THREE.BoxGeometry(w,h,d),mat);m.position.set(x,y,z);m.castShadow=true;m.receiveShadow=true;parent.add(m);return m}
const ground=new THREE.Mesh(new THREE.PlaneGeometry(1000,1000),mats.grass);ground.rotation.x=-Math.PI/2;ground.position.y=-.08;ground.receiveShadow=true;scene.add(ground);
// Main road and long road markings
box(16,.12,1000,mats.road,0,0,-180);
for(let z=-675;z<330;z+=12) box(.18,.025,5,mats.line,0,.075,z);
for(const x of [-8.1,8.1]) box(.3,.15,1000,mats.side,x,.01,-180);
for(let z=-650;z<280;z+=35){
  for(const x of [-1,1]){
    const bx=x*(15+Math.random()*10), bz=z+(Math.random()-.5)*12;
    const h=8+Math.random()*24,w=7+Math.random()*7,d=8+Math.random()*7;
    const colors=[0x8d9da8,0xb6a79a,0xc0c7cb,0x9babb7,0x9c9b91];
    const mat=new THREE.MeshStandardMaterial({color:colors[Math.floor(Math.random()*colors.length)],roughness:.9});
    const b=box(w,h,d,mat,bx,h/2-.05,bz); b.castShadow=false;
    const floors=Math.floor(h/3);
    for(let f=0;f<floors;f++) for(let wx=-1;wx<=1;wx++){
      const win=new THREE.Mesh(new THREE.BoxGeometry(.65,.75,.06),new THREE.MeshStandardMaterial({color:0x344e62,emissive:0x132432}));
      win.position.set(bx+wx*(w/3),1.4+f*2.5,bz+d/2+.035);scene.add(win);
    }
  }
  if(z%70===0) for(const x of [-12,12]){
    const t=box(.55,3,.55,mats.trunk,x,1.5,z);
    const crown=new THREE.Mesh(new THREE.ConeGeometry(2.1,5,7),mats.leaf);crown.position.set(x,4.3,z);crown.castShadow=true;scene.add(crown);
  }
}
for(let z=-620;z<260;z+=48){box(1.8,.25,1.2,mats.black,-5,.5,z);box(1.8,.25,1.2,mats.black,5,.5,z);}
const car=new THREE.Group();scene.add(car);car.position.set(0,0.15,6);
const bodyMat=new THREE.MeshStandardMaterial({color:settings.paint,metalness:.45,roughness:.28});
const body=box(1.85,.58,3.7,bodyMat,0,.72,0,car);
box(1.35,.58,1.75,mats.glass,0,1.25,-.25,car);
box(1.45,.15,.65,bodyMat,0,1.58,.7,car);
box(1.72,.14,.38,mats.black,0,.48,-1.4,car);
const wheels=[];
for(const x of [-1,1]) for(const z of [-1.2,1.2]){
  const wheel=new THREE.Mesh(new THREE.CylinderGeometry(.36,.36,.22,16),mats.black);wheel.rotation.z=Math.PI/2;wheel.position.set(x,.43,z);wheel.castShadow=true;car.add(wheel);wheels.push(wheel);
}
for(const x of [-.58,.58]){const head=new THREE.Mesh(new THREE.BoxGeometry(.42,.18,.08),new THREE.MeshStandardMaterial({color:0xfff2c4,emissive:0xffcc77,emissiveIntensity:1.2}));head.position.set(x,.8,-1.88);car.add(head)}
const remoteMat=new THREE.MeshStandardMaterial({color:0x3c91e6,metalness:.3,roughness:.3});
function makeRemote(){const g=new THREE.Group();box(1.8,.55,3.5,remoteMat,0,.7,0,g);box(1.25,.5,1.5,mats.glass,0,1.18,-.15,g);for(const x of [-.95,.95])for(const z of [-1.1,1.1]){const w=new THREE.Mesh(new THREE.CylinderGeometry(.33,.33,.2,12),mats.black);w.rotation.z=Math.PI/2;w.position.set(x,.38,z);g.add(w)}scene.add(g);return g}
function toast(s){$("toast").textContent=s;$("toast").classList.add("show");clearTimeout(toast.timer);toast.timer=setTimeout(()=>$("toast").classList.remove("show"),2600)}
function saveSettings(){localStorage.setItem("openroad-settings",JSON.stringify(settings));applyGraphics();applyLanguage();toast(tr("settingsSaved"))}
function tr(k){return (translations[settings.lang]||translations.en)[k]||translations.en[k]||k}
function applyLanguage(){
 document.documentElement.lang=settings.lang;
 document.querySelectorAll("[data-i18n]").forEach(el=>{const k=el.dataset.i18n;el.textContent=tr(k)});
 $("speedUnit").textContent=settings.unit==="mph"?"MPH":"KM/H";
 $("panelTitle").textContent=tr("driving");$("panelSubtitle").textContent=tr("subtitle");
 $("netStatus").textContent=ws&&ws.readyState===1?tr("online"):tr("offline");
}
function applyGraphics(){
 const scale={ "Very Low":.7,Low:.85,Medium:1,High:1.2,Ultra:1.35}[settings.quality]||1;
 renderer.setPixelRatio(Math.min(devicePixelRatio*scale,2));renderer.shadowMap.enabled=!["Very Low","Low"].includes(settings.quality);
 sun.castShadow=renderer.shadowMap.enabled;
}
function openSub(title,html){$("subPanel").classList.remove("hidden");$("subPanel").innerHTML=`<h3>${title}</h3>${html}<div class="row-actions"><button id="subClose">${tr("close")}</button></div>`;$("subClose").onclick=()=>$("subPanel").classList.add("hidden")}
function openSettings(){
 const html=`<label class="setting">${tr("language")}<select id="lang"><option value="en">English</option><option value="hi">हिंदी</option><option value="ru">Русский</option></select></label>
 <label class="setting">${tr("quality")}<select id="quality">${["Very Low","Low","Medium","High","Ultra"].map(x=>`<option>${x}</option>`).join("")}</select></label>
 <label class="setting">${tr("volume")}<input id="master" type="range" min="0" max="1" step=".05" value="${settings.master}"></label>
 <label class="setting">${tr("engine")}<input id="engine" type="range" min="0" max="1" step=".05" value="${settings.engine}"></label>
 <label class="setting">${tr("music")}<input id="music" type="range" min="0" max="1" step=".05" value="${settings.music}"></label>
 <label class="setting">${tr("sensitivity")}<input id="sensitivity" type="range" min=".4" max="2" step=".1" value="${settings.sensitivity}"></label>
 <label class="setting">${tr("units")}<select id="unit"><option value="kmh">km/h</option><option value="mph">mph</option></select></label>
 <div class="row-actions"><button id="applySettings" class="primary">${tr("apply")}</button><button id="resetSettings">${tr("reset")}</button></div>`;
 openSub(tr("settings"),html);
 $("lang").value=settings.lang;$("quality").value=settings.quality;$("unit").value=settings.unit;
 $("applySettings").onclick=()=>{settings.lang=$("lang").value;settings.quality=$("quality").value;settings.master=+$("master").value;settings.engine=+$("engine").value;settings.music=+$("music").value;settings.sensitivity=+$("sensitivity").value;settings.unit=$("unit").value;saveSettings()};
 $("resetSettings").onclick=()=>{settings={...defaults};saveSettings();openSettings()};
}
function openGarage(){
 const colors=[["Racing Red","#e53935"],["Ocean Blue","#1479c9"],["Sunset Orange","#f07824"],["Pearl White","#e9edf1"],["Midnight Black","#202631"],["Lime Green","#6cab3c"]];
 openSub(tr("garageTitle"),`<p class="subcopy">${tr("redCar")} <span class="badge">STARTER</span></p><label class="setting">${tr("paint")}<select id="paint">${colors.map(([n,c])=>`<option value="${c}">${n}</option>`).join("")}</select></label><p class="subcopy">Vehicle upgrades, additional models and economy are not included in this prototype yet.</p><button id="paintApply" class="primary">${tr("apply")}</button>`);
 $("paint").value=settings.paint;$("paintApply").onclick=()=>{settings.paint=$("paint").value;bodyMat.color.set(settings.paint);saveSettings();toast(tr("settingsSaved"))};
}
function openMissions(){openSub(tr("missionsTitle"),`<p class="subcopy">${tr("missionText")}</p><div class="setting">Distance driven <b id="distanceStat">${Math.round(totalDistance)} m</b></div><div class="setting">Fuel remaining <b>${Math.round(fuel)}%</b></div><p class="subcopy">Career progression, rewards and cloud saves need additional mission content/backend.</p>`)}
function openHelp(){openSub(tr("help"),`<p class="subcopy">${tr("helpText")}</p>`)}
function openMultiplayer(){
 openSub(tr("multiplayer"),`<p class="subcopy">This prototype includes a real WebSocket room sync client. Run the included Node.js server, then connect two browser/device clients to the same server address.</p><label class="setting">${tr("playerName")}<input id="playerName" type="text" maxlength="18" placeholder="Driver" value="${localStorage.getItem("openroad-name")||"Driver"}"></label><label class="setting">${tr("roomCode")}<input id="roomCode" type="text" maxlength="10" placeholder="ROAD123" value="${roomCode}"></label><label class="setting">Server URL<input id="serverUrl" type="text" value="${localStorage.getItem("openroad-server")||"ws://localhost:8080"}"></label><div class="row-actions"><button id="connectBtn" class="primary">${tr("connect")}</button><button id="disconnectBtn">${tr("disconnect")}</button></div><p id="multiInfo" class="subcopy">${ws&&ws.readyState===1?tr("online"):tr("offline")}</p>`);
 $("connectBtn").onclick=connectMultiplayer;$("disconnectBtn").onclick=disconnectMultiplayer;
}
function startAudio(){
 if(audioCtx)return;
 try{audioCtx=new (window.AudioContext||window.webkitAudioContext)();engineOsc=audioCtx.createOscillator();engineOsc.type="sawtooth";engineGain=audioCtx.createGain();engineGain.gain.value=0;engineOsc.frequency.value=65;engineOsc.connect(engineGain);engineGain.connect(audioCtx.destination);engineOsc.start()}catch(e){}
}
function honk(){startAudio();if(!audioCtx)return;const o=audioCtx.createOscillator(),g=audioCtx.createGain();o.type="square";o.frequency.value=390;g.gain.value=.0001;o.connect(g);g.connect(audioCtx.destination);const now=audioCtx.currentTime;g.gain.setTargetAtTime(.15*settings.master,now,.02);g.gain.setTargetAtTime(.0001,now+.28,.03);o.start();o.stop(now+.4)}
function connectMultiplayer(){
 const name=$("playerName").value.trim(),code=$("roomCode").value.trim().toUpperCase()||"PUBLIC",url=$("serverUrl").value.trim();
 if(!name||!code){toast(tr("roomNeed"));return}localStorage.setItem("openroad-name",name);localStorage.setItem("openroad-server",url);roomCode=code;
 try{ws=new WebSocket(url)}catch(e){toast(tr("serverDown"));return}
 $("multiInfo").textContent="Connecting…";
 ws.onopen=()=>{ws.send(JSON.stringify({type:"join",name,room:code}));$("netStatus").textContent=tr("online");$("multiInfo").textContent=tr("online");toast(tr("joined"))};
 ws.onmessage=(ev)=>{let m;try{m=JSON.parse(ev.data)}catch{return}
   if(m.type==="welcome"){myId=m.id;return}
   if(m.type==="players"){const keep=new Set();for(const p of m.players){if(p.id===myId)continue;keep.add(p.id);let r=remotePlayers.get(p.id);if(!r){r={mesh:makeRemote(),data:p};remotePlayers.set(p.id,r)}r.data=p;}
     for(const [id,r] of remotePlayers)if(!keep.has(id)){scene.remove(r.mesh);remotePlayers.delete(id)}
   }
   if(m.type==="error")toast(m.message||"Server error");
 };
 ws.onclose=()=>{$("netStatus").textContent=tr("offline");if($("multiInfo"))$("multiInfo").textContent=tr("offline");ws=null;myId=null};
 ws.onerror=()=>{toast(tr("serverDown"));$("multiInfo").textContent=tr("serverDown")};
}
function disconnectMultiplayer(){if(ws){ws.close();ws=null}remotePlayers.forEach(r=>scene.remove(r.mesh));remotePlayers.clear();myId=null;$("netStatus").textContent=tr("offline");toast(tr("left"))}
function setPlaying(v){running=v;paused=!v;$("overlay").classList.toggle("hidden",v);$("hud").classList.toggle("hidden",!v);$("controls").classList.toggle("hidden",!v);if(v)startAudio()}
$("playBtn").onclick=()=>setPlaying(true);
$("menuBtn").onclick=()=>{paused=true;running=false;$("overlay").classList.remove("hidden");$("hud").classList.remove("hidden");$("controls").classList.remove("hidden")};
$("pauseBtn").onclick=()=>{if(running){paused=true;running=false;toast(tr("paused"));$("overlay").classList.remove("hidden")}else setPlaying(true)};
$("settingsBtn").onclick=openSettings;$("garageBtn").onclick=openGarage;$("multiBtn").onclick=openMultiplayer;$("missionsBtn").onclick=openMissions;$("helpBtn").onclick=openHelp;
function bindHold(id,fn){const el=$(id);const down=e=>{e.preventDefault();fn(true)};const up=e=>{e.preventDefault();fn(false)};el.addEventListener("pointerdown",down);["pointerup","pointercancel","pointerleave"].forEach(ev=>el.addEventListener(ev,up))}
bindHold("leftBtn",v=>steering=v?-1:(steering===-1?0:steering));bindHold("rightBtn",v=>steering=v?1:(steering===1?0:steering));bindHold("gasBtn",v=>throttle=v?1:0);bindHold("brakeBtn",v=>braking=v?1:0);
$("hornBtn").addEventListener("pointerdown",e=>{e.preventDefault();honk()});
$("cameraBtn").onclick=()=>{cameraMode=(cameraMode+1)%3;toast(["Third-person","Hood view","Wide chase"][cameraMode])};
window.addEventListener("keydown",e=>{if(["ArrowLeft","a","A"].includes(e.key))steering=-1;if(["ArrowRight","d","D"].includes(e.key))steering=1;if(["ArrowUp","w","W"].includes(e.key))throttle=1;if(["ArrowDown","s","S"].includes(e.key))braking=1;if(e.key===" "){e.preventDefault();honk()}});
window.addEventListener("keyup",e=>{if(["ArrowLeft","a","A","ArrowRight","d","D"].includes(e.key))steering=0;if(["ArrowUp","w","W"].includes(e.key))throttle=0;if(["ArrowDown","s","S"].includes(e.key))braking=0});
let speed=0,last=performance.now(),sendClock=0;
function animate(now){
 requestAnimationFrame(animate);const dt=Math.min((now-last)/1000,.05);last=now;
 if(running&&!paused){
   speed+=throttle*13*dt;speed-=braking*25*dt;speed-=(!throttle&&!braking?3.5*dt:0);speed=Math.max(0,Math.min(speed,settings.quality==="Very Low"?28:48));
   car.rotation.y+=steering*settings.sensitivity*(.35+speed/55)*dt;
   const direction=new THREE.Vector3(Math.sin(car.rotation.y),0,-Math.cos(car.rotation.y));
   car.position.addScaledVector(direction,speed*dt*.45);
   car.position.x=Math.max(-6.2,Math.min(6.2,car.position.x));
   wheels.forEach(w=>w.rotation.x-=speed*dt*.1);
   totalDistance+=speed*dt*.45;fuel=Math.max(0,fuel-speed*dt*.0008);if(fuel<=0)speed=Math.min(speed,4);
   condition=Math.max(0,condition-(Math.abs(car.position.x)>5.8?dt*1.5:0));
   $("speed").textContent=Math.round(speed*(settings.unit==="mph"?.621371:1));$("fuel").textContent=Math.round(fuel)+"%";$("condition").textContent=Math.round(condition)+"%";$("gear").textContent=speed<1?"N":speed<15?"1":speed<28?"2":"3";
   if(engineGain&&audioCtx){engineOsc.frequency.setTargetAtTime(55+speed*5,audioCtx.currentTime,.1);engineGain.gain.setTargetAtTime((.015+throttle*.025)*settings.engine*settings.master,audioCtx.currentTime,.1)}
 }else if(engineGain&&audioCtx){engineGain.gain.setTargetAtTime(0,audioCtx.currentTime,.15)}
 let target,look;
 if(cameraMode===1){target=new THREE.Vector3(0,1.45,-.2).applyMatrix4(car.matrixWorld);look=new THREE.Vector3(0,1,-30).applyMatrix4(car.matrixWorld)}
 else {const back=cameraMode===2?12:8,height=cameraMode===2?7:4;const off=new THREE.Vector3(0,height,back).applyAxisAngle(new THREE.Vector3(0,1,0),car.rotation.y);target=car.position.clone().add(off);look=car.position.clone().add(new THREE.Vector3(0,1,-4).applyAxisAngle(new THREE.Vector3(0,1,0),car.rotation.y))}
 camera.position.lerp(target,.1);camera.lookAt(look);
 for(const r of remotePlayers.values()){const p=r.data;r.mesh.position.lerp(new THREE.Vector3(p.x,p.y,p.z),.22);r.mesh.rotation.y+=THREE.MathUtils.clamp(p.ry-r.mesh.rotation.y,-.1,.1)}
 if(ws&&ws.readyState===1&&now-sendClock>80){ws.send(JSON.stringify({type:"state",x:car.position.x,y:car.position.y,z:car.position.z,ry:car.rotation.y,speed,name:localStorage.getItem("openroad-name")||"Driver"}));sendClock=now}
 renderer.render(scene,camera);
}
requestAnimationFrame(animate);
window.addEventListener("resize",()=>{camera.aspect=innerWidth/innerHeight;camera.updateProjectionMatrix();renderer.setSize(innerWidth,innerHeight);applyGraphics()});
applyLanguage();applyGraphics();bodyMat.color.set(settings.paint);$("hud").classList.add("hidden");$("controls").classList.add("hidden");
