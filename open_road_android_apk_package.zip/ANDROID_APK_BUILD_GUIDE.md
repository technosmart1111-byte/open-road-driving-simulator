# Open Road — Android APK packaging

This package wraps the browser-game prototype in an Android app project using Capacitor.
**It does not contain a compiled APK yet.** An APK must be built with Android Studio/Android SDK.

## Requirements
- A computer (Windows, macOS, or Linux)
- Node.js 20+ and npm
- Android Studio with Android SDK installed
- Internet access (the prototype loads Three.js from a CDN)

## Build a debug APK
1. Extract this ZIP on your computer.
2. Open a terminal in the extracted `open_road_android_package` folder.
3. Install JavaScript dependencies:
   `npm install`
4. Generate the native Android project:
   `npx cap add android`
   If an `android` folder already exists, skip this step.
5. Copy the web app into Android:
   `npx cap sync android`
6. Open Android Studio:
   `npx cap open android`
7. In Android Studio, wait for Gradle sync to finish, then choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
8. Android Studio will show the output location for the debug APK (usually under `android/app/build/outputs/apk/debug/`).

## Install on your phone
Transfer the generated debug APK to your Android phone and install it. Android may ask you to allow installation from that file manager; only install APKs you built or trust.

## Multiplayer notes
The Android app is only the client. Online play needs the Node.js server in `server/` to be running on a reachable host.
- Local test server: `cd server`, `npm install`, `npm start`
- For another device on the same Wi-Fi, set the game server URL to `ws://YOUR_COMPUTER_LAN_IP:8080`.
- For internet production use, deploy the server behind TLS and use `wss://YOUR_PUBLIC_HOST`; configure the hosting, firewall, and secure transport.
- `localhost` on a phone means the phone itself, not your computer.

## Important limitations
- This packaging setup has not been compiled or tested on a physical Android device in this environment.
- The game remains a prototype. The UI language switch is implemented, but the 3D assets, driving physics, mission system, audio, and multiplayer are still limited as documented in `WEB_GAME_README.md`.
- The current Three.js module is fetched from a CDN, so the first launch requires internet access. A more robust offline-capable Android release should bundle the rendering library locally and be tested.
