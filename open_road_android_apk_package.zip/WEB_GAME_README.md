# Open Road — 3D Driving Simulator Starter

This is a **new playable browser prototype**, not a modification of your original project: the original source files were not attached to this chat.

## Included now
- 3D road, starter red car, buildings, trees, touch controls, keyboard controls, camera modes.
- English, Hindi and Russian UI language selection.
- Graphics presets (affects pixel ratio and shadows), speed units, steering sensitivity.
- Master/engine/music volume settings; simple synthesized engine and horn audio.
- Garage paint color selection.
- Local persistence for settings, paint, multiplayer server address and player name.
- A WebSocket multiplayer client and a minimal room-sync server for testing two or more clients.

## Run the browser game
1. Open this folder on a computer.
2. Start a static web server in this folder (ES modules generally should not be opened with `file://`):
   - Python: `python -m http.server 8000`
   - or any local static web server.
3. Visit `http://localhost:8000` in a modern browser.
4. Internet access is needed to load Three.js from jsDelivr and the optional Google Font.

For an Android phone on the same Wi-Fi, run the server on your computer and visit `http://COMPUTER_LAN_IP:8000` from the phone. Your firewall must permit the port.

## Run multiplayer server
Requires Node.js 18+.
1. In a terminal: `cd server`
2. Run `npm install`
3. Run `npm start`
4. The default WebSocket address is `ws://localhost:8080`.
5. In the game's Multiplayer panel, use the same server URL and room code on both clients.

For a phone connecting to a computer on the same Wi-Fi, enter `ws://COMPUTER_LAN_IP:8080` rather than `localhost`. For internet play, deploy the server on a public host, use `wss://` behind HTTPS/TLS, configure firewall/reverse proxy, and set the public URL in the game. Do not expose private credentials in client code.

## Honest limitations
This is a foundation prototype, not a finished AAA game. The current multiplayer server synchronizes simple player transforms in shared rooms; it is not authoritative vehicle physics and does not yet implement matchmaking, account authentication, chat moderation, friend invites, anti-cheat, race state, reconnect recovery or voice chat. The environment and vehicle are primitive generated geometry, not production assets. Graphics options are limited to controls actually implemented by this prototype. Music volume is stored but no music track is bundled. The mission screen is a basic distance challenge display; there is no full career/economy system, AI lane-driving traffic, pedestrian system, navigation route planner, full vehicle catalog, detailed vehicle damage, weather, day/night cycle, cloud save, leaderboards or rewards yet.

## Next step for your existing game
Upload the original project/source files (ZIP is easiest). Then this prototype can be adapted to your actual engine and existing code rather than replacing it.
