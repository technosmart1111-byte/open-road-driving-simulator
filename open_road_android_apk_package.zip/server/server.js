const WebSocket = require("ws");
const crypto = require("crypto");
const PORT = Number(process.env.PORT || 8080);
const wss = new WebSocket.Server({ port: PORT, maxPayload: 4096 });
const clients = new Map();
const rooms = new Map();

function safeText(value, max=18) {
  return String(value || "").replace(/[<>\\u0000-\\u001f]/g, "").trim().slice(0,max) || "Driver";
}
function send(ws, data) {
  if (ws.readyState === WebSocket.OPEN) ws.send(JSON.stringify(data));
}
function roomPlayers(room) {
  return [...clients.values()].filter(c=>c.room===room).map(c=>({
    id:c.id,name:c.name,x:c.x,y:c.y,z:c.z,ry:c.ry,speed:c.speed
  }));
}
function broadcastRoom(room) {
  const payload = {type:"players", players:roomPlayers(room)};
  for (const c of clients.values()) if(c.room===room) send(c.ws,payload);
}
wss.on("connection", ws => {
  const client = {ws,id:crypto.randomUUID(),name:"Driver",room:null,x:0,y:0,z:0,ry:0,speed:0,lastState:0};
  clients.set(client.id,client);
  send(ws,{type:"connected"});
  ws.on("message", raw => {
    let msg; try { msg=JSON.parse(raw.toString()); } catch { return; }
    if (!msg || typeof msg.type!=="string") return;
    if (msg.type==="join") {
      const room = safeText(msg.room,10).toUpperCase();
      if (!/^[A-Z0-9_-]{1,10}$/.test(room)) { send(ws,{type:"error",message:"Invalid room code"}); return; }
      client.room=room; client.name=safeText(msg.name);
      if(!rooms.has(room)) rooms.set(room,new Set());
      rooms.get(room).add(client.id);
      send(ws,{type:"welcome",id:client.id,room,players:roomPlayers(room)});
      broadcastRoom(room);
      return;
    }
    if (msg.type==="state" && client.room) {
      const now=Date.now();
      if(now-client.lastState<45) return; // rate limit state updates
      client.lastState=now;
      const num=(v,lo,hi)=>Number.isFinite(Number(v))?Math.max(lo,Math.min(hi,Number(v))):0;
      client.x=num(msg.x,-10000,10000); client.y=num(msg.y,-20,100); client.z=num(msg.z,-100000,100000);
      client.ry=num(msg.ry,-100000,100000); client.speed=num(msg.speed,0,100);
      if(msg.name) client.name=safeText(msg.name);
      broadcastRoom(client.room);
    }
  });
  ws.on("close",()=>{
    const room=client.room;
    clients.delete(client.id);
    if(room){const set=rooms.get(room);if(set){set.delete(client.id);if(!set.size)rooms.delete(room)}broadcastRoom(room)}
  });
});
wss.on("listening",()=>console.log(`Open Road multiplayer server listening on ws://localhost:${PORT}`));
