@echo off
npm install
if not exist android call npx cap add android
npx cap sync android
npx cap open android
pause
